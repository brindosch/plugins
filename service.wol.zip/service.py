import time

time.sleep(7)